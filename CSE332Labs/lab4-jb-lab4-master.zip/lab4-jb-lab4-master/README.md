# lab4
Base repository for lab4, sets up .gitignore and initializes the repository
