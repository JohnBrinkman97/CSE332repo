#include "stdafx.h"
#include "Lab1.h"
#include<iostream>
using namespace std; 




