#pragma once

enum arguments{programNameIndex = 0, inputFileIndex, expectedNumberOfArguments};
enum errorValues {
	noErrors = 0, wrongNumberOfArguments , couldntOpenFile
};



