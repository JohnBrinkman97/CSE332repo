========================================================================
    CONSOLE APPLICATION : Lab1-Brinkman Project Overview
========================================================================
Lab1
Author: John Brinkman 

Possible Errors & codes: 
Couldn't open file because it did not exist in correct directory = 2
wrong number of command line arguments = 1
success = 0

Errors I ran into:
File was in the wrong directory - program printed out that the file could not be opened
only inserted name of program in cmd line - printed out error that the user gave an incorrect number of commmand line arguments 

