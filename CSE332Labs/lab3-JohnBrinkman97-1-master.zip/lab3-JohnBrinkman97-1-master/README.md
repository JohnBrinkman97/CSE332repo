# lab3
lab 3 base repo, sets up .gitignore and intializes the repo
