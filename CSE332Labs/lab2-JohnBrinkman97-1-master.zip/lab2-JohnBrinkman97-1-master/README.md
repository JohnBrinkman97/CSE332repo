# lab2
Lab2 base repo. Sets up .gitignore and initializes the git repository
